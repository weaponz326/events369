import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-list-page',
  templateUrl: './events-list-page.component.html',
  styleUrls: ['./events-list-page.component.scss']
})
export class EventsListPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
