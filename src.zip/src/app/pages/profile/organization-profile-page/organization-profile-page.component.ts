import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organization-profile-page',
  templateUrl: './organization-profile-page.component.html',
  styleUrls: ['./organization-profile-page.component.scss']
})
export class OrganizationProfilePageComponent implements OnInit {

  constructor(
  ) { }

  ngOnInit(): void {
  }

  

}
