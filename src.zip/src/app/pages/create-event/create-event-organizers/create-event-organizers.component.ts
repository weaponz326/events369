import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-organizers',
  templateUrl: './create-event-organizers.component.html',
  styleUrls: ['./create-event-organizers.component.scss']
})
export class CreateEventOrganizersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
