import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-speakers',
  templateUrl: './create-event-speakers.component.html',
  styleUrls: ['./create-event-speakers.component.scss']
})
export class CreateEventSpeakersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
