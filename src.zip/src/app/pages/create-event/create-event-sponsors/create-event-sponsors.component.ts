import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-sponsors',
  templateUrl: './create-event-sponsors.component.html',
  styleUrls: ['./create-event-sponsors.component.scss']
})
export class CreateEventSponsorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
