import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-media',
  templateUrl: './create-event-media.component.html',
  styleUrls: ['./create-event-media.component.scss']
})
export class CreateEventMediaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
