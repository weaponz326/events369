import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-confirmed',
  templateUrl: './email-confirmed.component.html',
  styleUrls: ['./email-confirmed.component.scss']
})
export class EmailConfirmedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
