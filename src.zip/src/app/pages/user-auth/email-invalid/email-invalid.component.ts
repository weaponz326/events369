import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-invalid',
  templateUrl: './email-invalid.component.html',
  styleUrls: ['./email-invalid.component.scss']
})
export class EmailInvalidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
