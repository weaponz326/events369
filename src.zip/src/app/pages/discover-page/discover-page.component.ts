import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discover-page',
  templateUrl: './discover-page.component.html',
  styleUrls: ['./discover-page.component.scss']
})
export class DiscoverPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
