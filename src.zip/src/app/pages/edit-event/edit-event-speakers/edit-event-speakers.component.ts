import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-event-speakers',
  templateUrl: './edit-event-speakers.component.html',
  styleUrls: ['./edit-event-speakers.component.scss']
})
export class EditEventSpeakersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
