import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-event-sponsors',
  templateUrl: './edit-event-sponsors.component.html',
  styleUrls: ['./edit-event-sponsors.component.scss']
})
export class EditEventSponsorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
