import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-event-media',
  templateUrl: './edit-event-media.component.html',
  styleUrls: ['./edit-event-media.component.scss']
})
export class EditEventMediaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
