import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-event-organizers',
  templateUrl: './edit-event-organizers.component.html',
  styleUrls: ['./edit-event-organizers.component.scss']
})
export class EditEventOrganizersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
