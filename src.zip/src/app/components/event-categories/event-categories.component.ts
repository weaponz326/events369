import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-categories',
  templateUrl: './event-categories.component.html',
  styleUrls: ['./event-categories.component.scss']
})
export class EventCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
