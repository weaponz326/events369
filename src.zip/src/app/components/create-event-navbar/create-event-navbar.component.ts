import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-navbar',
  templateUrl: './create-event-navbar.component.html',
  styleUrls: ['./create-event-navbar.component.scss']
})
export class CreateEventNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
