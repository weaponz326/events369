import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-speakers',
  templateUrl: './speakers.component.html',
  styleUrls: ['./speakers.component.scss']
})
export class SpeakersComponent implements OnInit {

  constructor() { }

  @Input() speakers?: any;

  ngOnInit(): void {
  }

}
