import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-footer',
  templateUrl: './event-footer.component.html',
  styleUrls: ['./event-footer.component.scss']
})
export class EventFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
